10/Jan/2019: Released version 1.0
	-	You need read instruction in documentation folder
	